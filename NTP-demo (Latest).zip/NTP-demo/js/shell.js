// Adds the header, alert banner and toast area that every app page shares.
const NAV_LINKS = [
  { page: 'tasks', href: 'index.html', label: 'Tasks' },
  { page: 'search', href: 'search.html', label: 'Search' },
  { page: 'calendar', href: 'calendar.html', label: 'Calendar' },
];

function renderShell() {
  const currentPage = document.body.dataset.page;
  const navHtml = NAV_LINKS
    .map(({ page, href, label }) => `<a href="${href}"${page === currentPage ? ' aria-current="page"' : ''}>${label}</a>`)
    .join('');

  document.body.insertAdjacentHTML('afterbegin', `
    <header class="topbar">
      <div class="topbar-brand">
        <a href="dashboard.html" class="topbar-logo">NTP</a>
        <nav class="topbar-nav">${navHtml}</nav>
      </div>
      <div class="player">
        <strong id="player-level"></strong>
        <progress id="xp-progress" max="100" value="0"></progress>
        <span id="xp-text"></span>
      </div>
    </header>
    <div id="alert-banner" role="alert" hidden></div>`);
  document.body.insertAdjacentHTML('beforeend', '<div id="toast-area" aria-live="polite"></div>');
}
