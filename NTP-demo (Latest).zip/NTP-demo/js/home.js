// Tasks page: add tasks, see the full list, run the Pomodoro timer.
const resetDialog = $('#reset-confirm-dialog');

function handleTaskFormSubmit(event) {
  event.preventDefault();
  const deadline = new Date($('#task-deadline').value).getTime();
  if (deadline <= Date.now()) return showToast('Pick a deadline in the future.');
  addTask($('#task-title').value.trim(), deadline, $('#task-priority').value);
  event.target.reset();
}

$('#task-form').addEventListener('submit', handleTaskFormSubmit);
$('#pomodoro-toggle').addEventListener('click', togglePomodoro);
$('#pomodoro-reset').addEventListener('click', () => resetDialog.showModal());
$('#reset-confirm-yes').addEventListener('click', () => { resetDialog.close(); resetPomodoro(); });
$('#reset-confirm-no').addEventListener('click', () => resetDialog.close());

startPage(renderAchievements);
renderPomodoro();
