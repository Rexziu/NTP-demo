// Search page: the task list filters live as you type or change a dropdown.
$('#search-input').addEventListener('input', event => updateFilter('searchText', event.target.value.toLowerCase().trim()));
$('#priority-filter').addEventListener('change', event => updateFilter('priority', event.target.value));
$('#status-filter').addEventListener('change', event => updateFilter('status', event.target.value));

startPage();
