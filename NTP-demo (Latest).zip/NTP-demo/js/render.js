// Draws the parts of the screen that more than one page uses.
function createTaskHtml(task) {
  const deadlineText = new Date(task.deadline).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
  const statusHtml = task.completed
    ? '<span>Completed</span><span></span>'
    : '<span class="countdown"></span><button data-action="complete">Done</button>';
  return `
    <li class="task priority-${task.priority} ${task.completed ? 'completed' : ''}"
        data-id="${task.id}" data-created="${task.createdAt}" data-deadline="${task.deadline}">
      <div><strong>${escapeHtml(task.title)}</strong><small>${deadlineText}</small></div>
      ${statusHtml}
      <button data-action="delete" aria-label="Delete task">✕</button>
    </li>`;
}

function updateCountdowns() {
  const now = Date.now();
  document.querySelectorAll('.task:not(.completed)').forEach(taskElement => {
    const { created, deadline } = taskElement.dataset;
    const msLeft = deadline - now;
    const elapsedPercent = Math.min(100, ((now - created) / (deadline - created)) * 100);
    const countdown = taskElement.querySelector('.countdown');
    countdown.textContent = formatTimeLeft(msLeft);
    countdown.classList.toggle('urgent', msLeft <= ALERT_WINDOW_MS);
    taskElement.style.setProperty('--elapsed', `${elapsedPercent}%`);
  });
}

function renderTaskList() {
  const visibleTasks = getVisibleTasks();
  $('#task-list').innerHTML = visibleTasks.length
    ? visibleTasks.map(createTaskHtml).join('')
    : '<li class="empty">No tasks to show.</li>';
  updateCountdowns();
}

function renderPlayerStats() {
  const xpIntoLevel = state.xp % XP_PER_LEVEL;
  $('#player-level').textContent = `Level ${getLevel()}`;
  $('#xp-progress').value = xpIntoLevel;
  $('#xp-text').textContent = `${xpIntoLevel} / ${XP_PER_LEVEL} XP`;
}

function renderAchievements() {
  $('#achievement-list').innerHTML = ACHIEVEMENTS.map(achievement => {
    const unlockedClass = state.unlockedAchievementIds.includes(achievement.id) ? 'unlocked' : '';
    return `<li class="${unlockedClass}">${achievement.title}: ${achievement.description}</li>`;
  }).join('');
}
