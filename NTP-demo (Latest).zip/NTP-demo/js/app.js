// Shared start-up for every app page. Each page calls startPage() once, at the end.
let renderPage = () => {};

// Save, then redraw the current page.
function refresh() {
  saveState();
  renderPage();
}

function handleTaskListClick(event) {
  const actionButton = event.target.closest('button[data-action]');
  if (!actionButton) return;
  const taskId = Number(actionButton.closest('.task').dataset.id);
  if (actionButton.dataset.action === 'complete') completeTask(taskId);
  else deleteTask(taskId);
}

function handleKeyboardShortcut(event) {
  if (event.key === 'Escape') return event.target.blur();
  const isTyping = ['INPUT', 'SELECT', 'TEXTAREA'].includes(event.target.tagName);
  if (isTyping || event.ctrlKey || event.metaKey || event.altKey) return;
  const shortcut = SHORTCUTS[event.key.toLowerCase()];
  if (!shortcut) return;
  event.preventDefault();
  const field = $(shortcut.fieldSelector);
  if (field) field.focus();
  else location.href = shortcut.page;
}

// `renderPageExtras` draws whatever is unique to the page (calendar, achievements, ...).
function startPage(renderPageExtras = () => {}) {
  renderShell();
  renderPage = () => {
    renderPlayerStats();
    renderTaskList();
    runDeadlineAlerts();
    renderPageExtras();
  };

  $('#task-list').addEventListener('click', handleTaskListClick);
  document.addEventListener('keydown', handleKeyboardShortcut);
  if (location.hash === '#focus') $('#task-title, #search-input')?.focus();

  renderPage();
  penalizeMissedDeadlines();
  setInterval(updateCountdowns, 1000);
  setInterval(penalizeMissedDeadlines, ONE_MINUTE_MS);
  setInterval(runDeadlineAlerts, ONE_HOUR_MS);
}
