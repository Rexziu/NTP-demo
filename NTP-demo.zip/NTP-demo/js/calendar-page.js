

function handleCalendarDayClick(event) {
  const dayButton = event.target.closest('.day');
  if (!dayButton) return;
  const isAlreadySelected = state.filters.calendarDateKey === dayButton.dataset.date;
  updateFilter('calendarDateKey', isAlreadySelected ? null : dayButton.dataset.date);
  updateCalendarTaskHeading();
}

function changeCalendarMonth(monthOffset) {
  const { calendarMonth } = state;
  state.calendarMonth = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() + monthOffset, 1);
  renderCalendar();
}

function updateCalendarTaskHeading() {
  const key = state.filters.calendarDateKey;
  const heading = $('#calendar-task-heading');
  if (!key) {
    heading.textContent = 'All Tasks';
  } else {
    const date = new Date(key + 'T00:00:00');
    heading.textContent = `Tasks for ${date.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })}`;
  }
}

$('#calendar-grid').addEventListener('click', handleCalendarDayClick);
$('#calendar-prev').addEventListener('click', () => changeCalendarMonth(-1));
$('#calendar-next').addEventListener('click', () => changeCalendarMonth(1));

renderPlayerStats();
renderCalendar();
renderTaskList();
renderAchievements();
runDeadlineAlerts();
updateCalendarTaskHeading();
updateCountdowns();
setInterval(updateCountdowns, 1000);
setInterval(penalizeMissedDeadlines, ONE_MINUTE_MS);
setInterval(runDeadlineAlerts, ONE_HOUR_MS);
