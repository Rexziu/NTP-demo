
(function () {
  const tasks = storage.load('tasks', []);
  const xp    = storage.load('xp', 0);
  const unlocked = storage.load('achievements', []);

  const now       = Date.now();
  const completed = tasks.filter(t => t.completed).length;
  const pending   = tasks.filter(t => !t.completed).length;
  const overdue   = tasks.filter(t => !t.completed && t.deadline < now).length;
  const level     = Math.floor(xp / XP_PER_LEVEL) + 1;

  const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };

  set('stat-completed',    completed);
  set('stat-pending',      pending);
  set('stat-overdue',      overdue);
  set('stat-xp',           xp + ' XP');
  set('stat-level',        'Level ' + level);
  set('stat-achievements', unlocked.length + ' / ' + ACHIEVEMENTS.length);

  const todayKey = new Date().toLocaleDateString('en-CA');
  const todayTasks   = tasks.filter(t => new Date(t.deadline).toLocaleDateString('en-CA') === todayKey);
  const todayDone    = todayTasks.filter(t => t.completed).length;
  const pct = todayTasks.length ? Math.round((todayDone / todayTasks.length) * 100) : (completed > 0 ? 100 : 0);

  set('hero-pct', pct + '%');

  const circle = document.querySelector('.db-ring svg circle:last-child');
  if (circle) {
    const circumference = 2 * Math.PI * 54; // r=54
    const offset = circumference * (1 - pct / 100);
    circle.setAttribute('stroke-dasharray', circumference.toFixed(1));
    circle.setAttribute('stroke-dashoffset', offset.toFixed(1));
  }
})();
