
function handleTaskFormSubmit(event) {
  event.preventDefault();
  const deadline = new Date($('#task-deadline').value).getTime();
  if (deadline <= Date.now()) return showToast('Pick a deadline in the future.');
  addTask($('#task-title').value.trim(), deadline, $('#task-priority').value);
  event.target.reset();
}

function handleTaskListClick(event) {
  const actionButton = event.target.closest('button[data-action]');
  if (!actionButton) return;
  const taskId = Number(actionButton.closest('.task').dataset.id);
  if (actionButton.dataset.action === 'complete') completeTask(taskId);
  else deleteTask(taskId);
}

function handleCalendarDayClick(event) {
  const dayButton = event.target.closest('.day');
  if (!dayButton) return;
  const isAlreadySelected = state.filters.calendarDateKey === dayButton.dataset.date;
  updateFilter('calendarDateKey', isAlreadySelected ? null : dayButton.dataset.date);
  updateCalendarActiveDot();
}

function changeCalendarMonth(monthOffset) {
  const { calendarMonth } = state;
  state.calendarMonth = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() + monthOffset, 1);
  renderCalendar();
}

function toggleCalendarPopup() {
  const popup = $('#calendar-popup');
  const btn = $('#calendar-toggle-btn');
  const isOpen = !popup.hidden;
  popup.hidden = isOpen;
  btn.setAttribute('aria-expanded', String(!isOpen));
}

function updateCalendarActiveDot() {
  const dot = $('#cal-active-dot');
  if (dot) dot.hidden = !state.filters.calendarDateKey;
}

function handleKeyboardShortcut(event) {
  if (event.key === 'Escape') {
    // Close calendar popup if open
    const popup = $('#calendar-popup');
    if (!popup.hidden) { popup.hidden = true; $('#calendar-toggle-btn').setAttribute('aria-expanded', 'false'); return; }
    return event.target.blur();
  }
  const isTyping = ['INPUT', 'SELECT', 'TEXTAREA'].includes(event.target.tagName);
  if (isTyping || event.ctrlKey || event.metaKey || event.altKey) return;
  const shortcutTarget = SHORTCUT_TARGETS[event.key.toLowerCase()];
  if (shortcutTarget) { event.preventDefault(); $(shortcutTarget).focus(); }
}

function bindEvents() {
  $('#task-form').addEventListener('submit', handleTaskFormSubmit);
  $('#search-input').addEventListener('input', event => updateFilter('searchText', event.target.value.toLowerCase().trim()));
  $('#priority-filter').addEventListener('change', event => updateFilter('priority', event.target.value));
  $('#status-filter').addEventListener('change', event => updateFilter('status', event.target.value));
  $('#task-list').addEventListener('click', handleTaskListClick);
  $('#calendar-toggle-btn').addEventListener('click', event => { event.stopPropagation(); toggleCalendarPopup(); });
  $('#calendar-grid').addEventListener('click', handleCalendarDayClick);
  $('#calendar-prev').addEventListener('click', () => changeCalendarMonth(-1));
  $('#calendar-next').addEventListener('click', () => changeCalendarMonth(1));
  $('#pomodoro-toggle').addEventListener('click', togglePomodoro);
  $('#pomodoro-reset').addEventListener('click', () => $('#reset-confirm-dialog').showModal());
  $('#reset-confirm-yes').addEventListener('click', () => { $('#reset-confirm-dialog').close(); resetPomodoro(); });
  $('#reset-confirm-no').addEventListener('click', () => $('#reset-confirm-dialog').close());
  // Close popup when clicking outside
  document.addEventListener('click', event => {
    const popup = $('#calendar-popup');
    if (!popup.hidden && !$('.calendar-popup-wrap').contains(event.target)) {
      popup.hidden = true;
      $('#calendar-toggle-btn').setAttribute('aria-expanded', 'false');
    }
  });
  document.addEventListener('keydown', handleKeyboardShortcut);
}
